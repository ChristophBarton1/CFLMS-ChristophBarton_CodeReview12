<?php get_header(); ?>
<h1><center>Chris Coding and Travel Blog</center><h1>
	 <hr />
<h4><center> Live.Code. and Travel	</center><h4>
 <hr />

<div class="container">


	<center><div class="image"><img src="https://images.pexels.com/photos/346885/pexels-photo-346885.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"></div><center>	
	<div class="image"><img scr="https://images.pexels.com/photos/2174656/pexels-photo-2174656.jpeg?auto=compress&cs=tinysrgb&dpr=3&h=750&w=1260"></div><center>


	<div class="row fprow">

		<center> Top 10 Countrys and Citys i travled this year <center>

	<hr/>

		<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Country</th>
      <th scope="col">City</th>
      <th scope="col">Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Austria</td>
      <td>Vienna</td>
      <td>wonderful old city</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Germany</td>
      <td>Berlin</td>
      <td>a must see captial city</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>China</td>
      <td>Hong Kong</td>
      <td>A wonderful city with much skyscrapers</td>
    </tr>
    <tr>
      <th scope="row">4</th>
      <td>Usa</td>
      <td>San Fransisco</td>
      <td>Wonderful City with high technology companys</td>
    </tr>
    <tr>
      <th scope="row">5</th>
      <td>Italy</td>
      <td>Rom</td>
      <td>You will never forget this overpriced but beautiful city</td>
    </tr>
     <tr>
      <th scope="row">6</th>
      <td>Africa</td>
      <td>Wakanda</td>
      <td>For every nerd like me</td>
    </tr>
    <tr>
      <th scope="row">7</th>
      <td>Czech Republic</td>
      <td>Prague</td>
      <td>The best time to visit is in spring</td>
    </tr>
    <tr>
      <th scope="row">8</th>
      <td>China</td>
      <td>Hong Kong</td>
      <td>You can start your Developer carreer here</td>
    </tr>
    <tr>
      <th scope="row">9</th>
      <td>Usa</td>
      <td>San Fransisco</td>
      <td>einfach beste</td>
    </tr>
    <tr>
      <th scope="row">10</th>
      <td>Netherlands</td>
      <td>Amsterdam</td>
      <td>Drugs</td>
    </tr>


  </tbody>

</table>
</div>
<div class="row fprow">

		<div class="col-4">1</div>
		<div class="col-4">2</div>
		<div class="col-4">3</div>

</hr>

		<div class="col-4">4</div>
		<div class="col-4">5</div>
		<div class="col-4">6</div>
</hr>

		<div class="col-4">7</div>
		<div class="col-4">8</div>
		<div class="col-4">9</div>
		</hr>

		<div class="col-4">10</div>



<?php get_footer(); ?>