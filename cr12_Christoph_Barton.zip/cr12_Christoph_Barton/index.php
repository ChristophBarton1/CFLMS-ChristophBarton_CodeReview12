<?php get_header(); ?>
		

			<div class="container">
			<h1>Hello from my theme</h1>
			<p>this is also from the theme</p>
			<div class="content">

			<?php if(have_posts()) : ?>
				<?php while(have_posts()) : the_post(); ?>

					<h2><a href="<?php the_permalink(); ?>"> <?php the_title(); ?></a></h2>
					<p><?php the_time('F j, Y g:i a'); ?></p>
					<div class="description"><?php the_excerpt(); ?>
					</div>
				<?php endwhile; ?>
				<?php else :?>
					<?php_('No Posts found'); ?>
				<?php endif; ?>
			</div>

			</div>

			<?php get_footer(); ?>