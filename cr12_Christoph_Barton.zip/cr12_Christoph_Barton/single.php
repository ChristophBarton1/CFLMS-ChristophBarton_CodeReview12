<?php get_header(); ?>

<div class="container single">
			<h1>Hello from a single post</h1>
			<p>this is also from the theme</p>
			<div class="content">

			<?php if(have_posts()) : ?>
				<?php while(have_posts()) : the_post(); ?>

					<h2><?php the_title(); ?></h2>
					<?php if(has_post_thumbnail()): ?>
						<?php the_post_thumbnail(); ?>
					<?php endif; ?>
					<p><?php the_time('F j, Y g:i a'); ?></p>
					<p><?php the_author(); ?></p>
					<div class="description"><?php the_content(); ?>
					</div>
					<div><?php comments_template(); ?></div>
				<?php endwhile; ?>
				<?php else :?>
					<?php_('No Posts found'); ?>
				<?php endif; ?>
			</div>

			<?php 
			if(is_active_sidebar('sidebar')):
				dynamic_sidebar('Sidebar');
			endif;
				?>

			</div>

			<?php get_footer(); ?>